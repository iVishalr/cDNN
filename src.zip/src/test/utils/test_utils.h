// void TEST_DOT();
// void write_DOT_TESTS();
// dARRAY * pre_process(char * test);
// void get_shape_arr(char * shape,int * dims);
// void get_martix_arr(dARRAY * matrix, char * test);
// dARRAY * perform_dot(dARRAY * matrix);
// int validate(dARRAY * matrix);
// void sleep(int milliseconds);