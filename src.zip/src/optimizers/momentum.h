#ifndef MOMENTUM_H
#define MOMENTUM_H

#include "../utils/utils.h"

#ifdef __cplusplus
extern "C"{
#endif
  void Momentum();
#ifdef __cplusplus
}
#endif
#endif