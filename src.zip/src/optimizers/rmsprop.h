#ifndef RMSPROP_H
#define RMSPROP_H

#ifdef __cplusplus
extern "C"{
#endif
  void RMSProp();
#ifdef __cplusplus
}
#endif

#endif