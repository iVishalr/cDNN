#ifndef GRADIENT_DESCENT_H
#define GRADIENT_DESCENT_H

#include "../utils/utils.h"

#ifdef __cplusplus
extern "C"{
#endif
  void SGD();
#ifdef __cplusplus
}
#endif
#endif