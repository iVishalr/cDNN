#ifndef ADAM_H
#define ADAM_H

#ifdef __cplusplus
extern "C"{
#endif
  void adam();
#ifdef __cplusplus
}
#endif

#endif