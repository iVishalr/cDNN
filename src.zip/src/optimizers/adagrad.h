#ifndef ADAGRAD_H
#define ADAGRAD_H

#ifdef __cplusplus
extern "C"{
#endif
  void adagrad();
#ifdef __cplusplus
}
#endif

#endif